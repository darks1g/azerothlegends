package com.wowapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WowappApplicationTests {

	@Test
	void contextLoads() {
	}

}
